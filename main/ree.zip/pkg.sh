sudo apt install -y mediainfo ffmpeg wget gcc python3-pip python3 aria2
pip3 install -U -r requirements.txt